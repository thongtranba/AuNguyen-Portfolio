<?php 
define("SMTP_HOST", "smtp.gmail.com");
define("SMTP_USERNAME", "tranbathong93@gmail.com");
define("SMTP_SECRET", "autftgwgerlibbum");
define("OWNER_EMAIL", "tranbathong93@gmail.com");
 ?>